import azure.functions as func
import logging
import os
import json
import requests

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)  # FUNCTION level: requires ?code=... key

@app.route(route="send-result-email")
def send_result_email(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger: send_result_email function processed a request.')

    try:
        # Get JSON body from the request (from your ASP.NET app)
        req_body = req.get_json()

        # Extract required fields
        user_email = req_body.get('email')
        result = req_body.get('result')          # e.g., "TUMEUR DÉTECTÉE"
        probability = req_body.get('probability') # e.g., "92.5"
        image_url = req_body.get('image_url')    # SAS URL from Blob Storage

        if not user_email or not result:
            return func.HttpResponse(
                json.dumps({"error": "Missing required fields: 'email' and 'result' are required."}),
                status_code=400,
                mimetype="application/json"
            )

        # Get Brevo API credentials from environment variables
        BREVO_API_KEY = os.environ.get('brevoAPIkey')  # ← Changed to match your Azure name
        SENDER_EMAIL = os.environ.get('sender_email')

        if not BREVO_API_KEY:
            logging.error("brevoAPIkey is missing in environment variables.")
            return func.HttpResponse(
                json.dumps({"error": "Server configuration error: Missing API key."}),
                status_code=500,
                mimetype="application/json"
            )

        if not SENDER_EMAIL:
            logging.error("BREVO_SENDER_EMAIL is missing in environment variables.")
            return func.HttpResponse(
                json.dumps({"error": "Server configuration error: Missing sender email."}),
                status_code=500,
                mimetype="application/json"
            )

        # Brevo SMTP API endpoint
        url = "https://api.brevo.com/v3/smtp/email"

        # Email payload (HTML + plain text fallback)
        payload = {
            "sender": {"email": SENDER_EMAIL, "name": "BreastScan AI"},
            "to": [{"email": user_email}],
            "subject": "Votre Analyse BreastScan",
            "htmlContent": f"""
                <h2>Résultat de votre analyse</h2>
                <p><strong>Résultat :</strong> {result}</p>
                <p><strong>Confiance :</strong> {probability}%</p>
                <p><strong>Image analysée :</strong> <a href="{image_url}">Voir l'image</a></p>
                <br>
                <p>Cette analyse est indicative et ne remplace pas un avis médical.</p>
                <p>Merci d'utiliser BreastScan ! ♡</p>
            """,
            "textContent": f"""
                Résultat : {result}
                Confiance : {probability}%
                Image : {image_url}
                Cette analyse est indicative et ne remplace pas un avis médical.
                Merci ! ♡
            """
        }

        headers = {
            "api-key": BREVO_API_KEY,
            "Content-Type": "application/json",
            "accept": "application/json"
        }

        # Send the email
        response = requests.post(url, headers=headers, data=json.dumps(payload))

        if response.status_code == 201:
            logging.info(f"Email successfully sent to {user_email}")
            return func.HttpResponse(
                json.dumps({"message": "Email sent successfully!", "status": response.status_code}),
                status_code=200,
                mimetype="application/json"
            )
        else:
            logging.error(f"Brevo API error: {response.text}")
            return func.HttpResponse(
                json.dumps({"error": "Failed to send email", "details": response.text}),
                status_code=response.status_code,
                mimetype="application/json"
            )

    except ValueError:
        return func.HttpResponse(
            json.dumps({"error": "Invalid JSON in request body."}),
            status_code=400,
            mimetype="application/json"
        )
    except Exception as e:
        logging.error(f"Unexpected error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": f"Server error: {str(e)}"}),
            status_code=500,
            mimetype="application/json"
        )