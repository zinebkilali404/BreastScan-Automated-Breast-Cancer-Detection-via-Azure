using Azure.Storage.Blobs;
using Azure.Storage.Sas;
using Microsoft.Extensions.Configuration;

namespace S7ABA.Services
{
    public class BlobStorageService
    {
        private readonly BlobContainerClient _containerClient;

        public BlobStorageService(IConfiguration configuration)
        {
            // Read the connection string from "ConnectionStrings:AzureBlobStorage"
            var connectionString = configuration.GetConnectionString("AzureBlobStorage");
            var containerName = configuration["AzureBlobStorage:ContainerName"];

            if (string.IsNullOrEmpty(connectionString) || string.IsNullOrEmpty(containerName))
            {
                throw new InvalidOperationException("Azure Blob Storage configuration is missing.");
            }

            var blobServiceClient = new BlobServiceClient(connectionString);
            _containerClient = blobServiceClient.GetBlobContainerClient(containerName);

            // Create the container if it doesn't exist (safe to call every time)
            _containerClient.CreateIfNotExists();
        }

        public async Task<(string BlobName, string BlobUrl)> UploadImageAsync(Stream imageStream, string originalFileName)
        {
            // Generate a unique blob name with timestamp and GUID
            var blobName = $"scans/{DateTime.UtcNow:yyyyMMdd-HHmmss}_{Guid.NewGuid()}_{originalFileName}";

            var blobClient = _containerClient.GetBlobClient(blobName);

            // Upload the image with correct content type
            await blobClient.UploadAsync(imageStream, new Azure.Storage.Blobs.Models.BlobUploadOptions
            {
                HttpHeaders = new Azure.Storage.Blobs.Models.BlobHttpHeaders
                {
                    ContentType = "image/jpeg" // Adjust to "image/png" if needed
                }
            });

            // Return the blob name and the base URI (SAS will be added later)
            return (blobName, blobClient.Uri.ToString());
        }

        public string GenerateReadSasUrl(string blobName, int hoursValid = 24)
        {
            var blobClient = _containerClient.GetBlobClient(blobName);

            if (!blobClient.CanGenerateSasUri)
            {
                throw new InvalidOperationException("Cannot generate SAS URI. Check account key permissions.");
            }

            var sasBuilder = new BlobSasBuilder
            {
                BlobContainerName = _containerClient.Name,
                BlobName = blobName,
                Resource = "b", // blob
                StartsOn = DateTimeOffset.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTimeOffset.UtcNow.AddHours(hoursValid),
                Protocol = SasProtocol.Https
            };

            sasBuilder.SetPermissions(BlobSasPermissions.Read);

            var sasUri = blobClient.GenerateSasUri(sasBuilder);
            return sasUri.ToString();
        }
    }
}