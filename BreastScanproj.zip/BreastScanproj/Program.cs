using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Azure.Storage.Blobs; // For BlobServiceClient
using S7ABA.Data;
using S7ABA.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient();

// Register your services
builder.Services.AddSingleton<DatabaseHelper>();
builder.Services.AddSingleton<BlobStorageService>();

// Register BlobServiceClient for the test endpoint
builder.Services.AddSingleton(sp =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var connectionString = config.GetConnectionString("AzureBlobStorage");
    return new BlobServiceClient(connectionString);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Test endpoint to verify Blob connection
app.MapGet("/test-blob", (BlobServiceClient blobClient) =>
{
    return $"BlobServiceClient is working! Account name: {blobClient.AccountName}";
});

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();