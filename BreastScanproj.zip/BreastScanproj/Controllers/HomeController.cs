using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using S7ABA.Data;
using S7ABA.Services;
using MySqlConnector;
using System.Text.Json;
using S7ABA.Models;
using System.Net.Http;
using System.Text;

namespace S7ABA.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly DatabaseHelper _dbHelper;
        private readonly BlobStorageService _blobService;

        public HomeController(
            IConfiguration configuration,
            IHttpClientFactory httpClientFactory,
            DatabaseHelper dbHelper,
            BlobStorageService blobService)
        {
            _configuration = configuration;
            _httpClientFactory = httpClientFactory;
            _dbHelper = dbHelper;
            _blobService = blobService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(IFormFile Image, string Email = null)
        {
            if (Image == null || Image.Length == 0)
            {
                ViewBag.Error = "Veuillez sélectionner une image à analyser.";
                return View();
            }

            var predictionUrl = _configuration["CustomVision:PredictionUrl"];
            var predictionKey = _configuration["CustomVision:PredictionKey"];

            if (string.IsNullOrEmpty(predictionUrl) || string.IsNullOrEmpty(predictionKey))
            {
                ViewBag.Error = "Configuration Custom Vision manquante.";
                return View();
            }

            try
            {
                // 1. Call Azure Custom Vision
                Console.WriteLine("Étape 1: Appel à Custom Vision...");
                var client = _httpClientFactory.CreateClient();
                using var content = new StreamContent(Image.OpenReadStream());
                content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                client.DefaultRequestHeaders.Add("Prediction-Key", predictionKey);

                var response = await client.PostAsync(predictionUrl, content);
                var jsonResponse = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"Custom Vision a échoué : {response.StatusCode} - {jsonResponse}");
                    ViewBag.Error = $"Erreur Custom Vision : {response.StatusCode}";
                    return View();
                }

                Console.WriteLine("Custom Vision OK.");
                ViewBag.JsonResponse = jsonResponse;

                // 2. Parse prediction
                using var doc = JsonDocument.Parse(jsonResponse);
                var predictions = doc.RootElement.GetProperty("predictions").EnumerateArray()
                    .OrderByDescending(p => p.GetProperty("probability").GetDouble())
                    .FirstOrDefault();

                if (predictions.ValueKind == JsonValueKind.Undefined)
                {
                    ViewBag.Error = "Aucune prédiction valide trouvée.";
                    return View();
                }

                var tagName = predictions.GetProperty("tagName").GetString()?.ToLower();
                var probability = predictions.GetProperty("probability").GetDouble() * 100;

                ViewBag.Result = tagName == "cancerous" ? "TUMEUR DÉTECTÉE" : "AUCUNE TUMEUR DÉTECTÉE";
                ViewBag.Probability = probability.ToString("F2");
                ViewBag.IsCancerous = tagName == "cancerous";

                Console.WriteLine($"Prédiction : {ViewBag.Result} ({ViewBag.Probability}%)");

                // 3. Upload to Blob Storage
                Console.WriteLine("Étape 3: Upload vers Azure Blob...");
                Image.OpenReadStream().Position = 0;
                (var blobName, _) = await _blobService.UploadImageAsync(Image.OpenReadStream(), Image.FileName);
                string sasUrl = _blobService.GenerateReadSasUrl(blobName, 24);

                if (string.IsNullOrEmpty(sasUrl))
                {
                    ViewBag.Error = "Échec de la génération de l'URL SAS.";
                    return View();
                }

                Console.WriteLine($"Image uploadée avec succès : {sasUrl}");
                ViewBag.ImageUrl = sasUrl;

                // 4. Save to MySQL
                Console.WriteLine("Étape 4: Connexion à la base de données...");
                using var conn = _dbHelper.GetConnection();
                await conn.OpenAsync();
                Console.WriteLine($"Connecté à la base : {conn.Database} sur serveur {conn.DataSource}");

                using var transaction = await conn.BeginTransactionAsync();

                try
                {
                    string sql = @"
                        INSERT INTO mammogram_history 
                        (result_id, image_url, result, probability) 
                        VALUES (@ResultId, @ImageUrl, @Result, @Probability)";

                    using var cmd = new MySqlCommand(sql, conn, transaction);
                    cmd.Parameters.AddWithValue("@ResultId", DateTime.Now.Ticks & 0x7FFFFFFF);
                    cmd.Parameters.AddWithValue("@ImageUrl", sasUrl); // NOT NULL column
                    cmd.Parameters.AddWithValue("@Result", ViewBag.Result); // NOT NULL column
                    cmd.Parameters.AddWithValue("@Probability", Math.Round(probability, 2));

                    Console.WriteLine("Exécution de l'INSERT...");
                    int rowsAffected = await cmd.ExecuteNonQueryAsync();
                    Console.WriteLine($"Lignes insérées : {rowsAffected}");

                    if (rowsAffected == 0)
                    {
                        throw new Exception("Aucune ligne insérée (contrainte de base violée ?).");
                    }

                    await transaction.CommitAsync();
                    Console.WriteLine("Transaction validée avec succès !");
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    Console.WriteLine($"ERREUR BASE DE DONNÉES : {ex.Message}\n{ex.StackTrace}");
                    ViewBag.Error = $"Erreur lors de l'enregistrement en base : {ex.Message}";
                    return View();
                }

                // 5. Send email if provided
                if (!string.IsNullOrEmpty(Email))
                {
                    Console.WriteLine("Étape 5: Envoi de l'email...");
                    var functionUrl = "https://zinebx2mail-h6cwdwffeadqeke4.swedencentral-01.azurewebsites.net/api/send-result-email?code=YOUR_KEY_FROM_PORTAL";
                    var payload = new
                    {
                        email = Email,
                        result = ViewBag.Result,
                        probability = ViewBag.Probability,
                        image_url = sasUrl
                    };

                    using var httpClient = _httpClientFactory.CreateClient();
                    var jsonPayload = JsonSerializer.Serialize(payload);
                    var httpContent = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                    var emailResponse = await httpClient.PostAsync(functionUrl, httpContent);

                    if (emailResponse.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Email envoyé avec succès.");
                        ViewBag.EmailSent = true;
                    }
                    else
                    {
                        var errorContent = await emailResponse.Content.ReadAsStringAsync();
                        Console.WriteLine($"Erreur email : {emailResponse.StatusCode} - {errorContent}");
                        ViewBag.EmailError = $"Erreur email : {emailResponse.StatusCode} - {errorContent}";
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ERREUR GÉNÉRALE : {ex.Message}\n{ex.StackTrace}");
                ViewBag.Error = $"Erreur inattendue : {ex.Message}";
            }

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}