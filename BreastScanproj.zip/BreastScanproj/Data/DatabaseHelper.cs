using MySqlConnector;
using Microsoft.Extensions.Configuration;

namespace S7ABA.Data
{
    public class DatabaseHelper
    {
        private readonly IConfiguration _configuration;

        public DatabaseHelper(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public MySqlConnection GetConnection()
        {
            string connectionString = _configuration.GetConnectionString("webapp_db");
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new InvalidOperationException("Connection string 'webapp_db' not found.");
            }
            return new MySqlConnection(connectionString);
        }
    }
}
